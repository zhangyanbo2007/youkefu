//
//  ViewController.swift
//  socketio-demo
//
//  Created by Daniel on 2018/11/23.
//  Copyright © 2018 Daniel. All rights reserved.
//

import UIKit
import SocketIO

class ViewController: UIViewController {
    var manager:SocketManager?
    var socket: SocketIOClient?
    
    //发送内容
    var mySendString = ""
    //发送方
    var myLoginName = ""
    //接收方
    var receiverName = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        connectSocket()
    }

    
    /**
     连接Socket
     */
    private func connectSocket() {
//        let socketURL = URL(string:"http://192.168.30.134:9081")!
//        let config = SocketIOClientConfiguration(arrayLiteral: .compress, .log(true), .forceNew(true), .reconnectAttempts(-1), .reconnectWait(4), .connectParams(["userid":"f8870e8c7fd4b0039c23a301ce3d924b","appid":"00QhVB","orgi":"ukewo","osname":"ios","browser":"safari","session":"f2da3b8bc1314bcf9902f05da3b72844"]))

        let socketURL = URL(string:"http://localhost:9081")!
        let config = SocketIOClientConfiguration(arrayLiteral: .compress, .log(true), .forceNew(true), .reconnectAttempts(-1), .reconnectWait(4), .connectParams(["userid":"f8870e8c7fd4b0039c23a301ce3d924b","appid":"01t81x","orgi":"ukewo","osname":"ios","browser":"safari","session":"f2da3b8bc1314bcf9902f05da3b72844"]))

        manager = SocketManager(socketURL: socketURL, config: config)

        socket = manager!.socket(forNamespace: "/im/user")
        
        //        let url = URL(string: "http://192.168.30.134:9081/im/user?userid=f8870e8c7fd4b0039c23a301ce3d924b&orgi=ukewo&browser=1.1&osname=ios&session=f2da3b8bc1314bcf9902f05da3b72844&appid=00QhVB")
        //        let url = URL(string: "http://127.0.0.1:9081/im/user?userid=f8870e8c7fd4b0039c23a301ce3d924b&orgi=ukewo&browser=1.1&osname=ios&session=f2da3b8bc1314bcf9902f05da3b72844&appid=01t81x")
        //        let url = URL(string: "http://uk.ukewo.cn:9081/im/user?userid=f8870e8c7fd4b0039c23a301ce3d924b&orgi=ukewo&browser=1.1&osname=ios&session=f2da3b8bc1314bcf9902f05da3b72844&appid=0RscUV")
        
        //监听连接Socket连接是否成功
        socket?.on("connect", callback: {(_ data: [Any]?, _ ack: SocketAckEmitter?) -> Void in
            print(">>>>>>>>>>>>>socket connected!<<<<<<<<<<<<<")
        })
        
        socket?.on("agentstatus", callback: {(_ data: [Any]?, _ ack: SocketAckEmitter?) -> Void in
            print(">>>>>>>>>>>>>socket agentstatus!<<<<<<<<<<<<<")
        })
        
        socket?.on("status", callback: {(_ data: [Any]?, _ ack: SocketAckEmitter?) -> Void in
            print(">>>>>>>>>>>>>socket status!<<<<<<<<<<<<<")
        })
        
        socket?.on("message", callback: {(_ data: [Any]?, _ ack: SocketAckEmitter?) -> Void in
            print(">>>>>>>>>>>>>socket message!<<<<<<<<<<<<<")
        })
        
        socket?.on("disconnect", callback: {(_ data: [Any]?, _ ack: SocketAckEmitter?) -> Void in
            print(">>>>>>>>>>>>>socket disconnect!<<<<<<<<<<<<<")
        })
        
        socket?.connect()
    }

}

