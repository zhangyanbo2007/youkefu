# Simple Test

This is a very simple example on how to use Starscream.

# Usage

First make sure you have the gem dependencies of websocket server.

```
gem install em-websocket
gem install faker
```

Next simply run:

```
ruby ws-server.rb
```

After that, start and run the xCode project. Echo to your heart's desire.