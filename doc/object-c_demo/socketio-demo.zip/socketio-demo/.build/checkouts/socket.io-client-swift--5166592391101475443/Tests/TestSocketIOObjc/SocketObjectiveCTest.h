//
// Created by Erik Little on 10/21/17.
//


@import Dispatch;
@import Foundation;
@import XCTest;
@import SocketIO;

@interface SocketObjectiveCTest : XCTestCase

@property SocketIOClient* socket;
@property SocketManager* manager;

@end
