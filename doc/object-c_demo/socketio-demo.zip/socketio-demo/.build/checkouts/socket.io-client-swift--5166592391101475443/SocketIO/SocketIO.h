//
//  SocketIO-Mac.h
//  SocketIO-Mac
//
//  Created by Nacho Soto on 7/11/15.
//
//

#import <Foundation/Foundation.h>

//! Project version number for SocketIO-Mac.
FOUNDATION_EXPORT double SocketIO_MacVersionNumber;

//! Project version string for SocketIO-Mac.
FOUNDATION_EXPORT const unsigned char SocketIO_MacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SocketIO_Mac/PublicHeader.h>


