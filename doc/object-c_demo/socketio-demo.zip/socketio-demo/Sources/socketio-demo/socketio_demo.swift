struct socketio_demo {
    var text = "Hello, World!"
}
