import XCTest
@testable import socketio_demo

final class socketio_demoTests: XCTestCase {
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(socketio_demo().text, "Hello, World!")
    }

    static var allTests = [
        ("testExample", testExample),
    ]
}
