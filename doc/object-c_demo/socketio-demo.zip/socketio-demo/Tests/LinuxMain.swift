import XCTest

import socketio_demoTests

var tests = [XCTestCaseEntry]()
tests += socketio_demoTests.allTests()
XCTMain(tests)